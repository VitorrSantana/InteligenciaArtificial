from No import  No

class Adjacente:

    def __init__(self,no:No) -> None:
        self.nodo = no
